package com.oops.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Enum-Lesson1}
 * @Date: {2022/05/10 && 7:34 PM}
 */

public interface CarDetails {

    void zavat(); // method
    void checkPribor();
    void runAway();
}
