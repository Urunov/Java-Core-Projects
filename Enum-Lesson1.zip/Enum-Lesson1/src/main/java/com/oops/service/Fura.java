package com.oops.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Enum-Lesson1}
 * @Date: {2022/05/10 && 7:50 PM}
 */
public interface  Fura {
    //
     int balanonces();
     int tires();



}
