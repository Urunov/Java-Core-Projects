package com.oops.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Enum-Lesson1}
 * @Date: {2022/05/10 && 7:40 PM}
 */
public interface CarDetailsCustom {

    int millage();
    boolean colorType();

}
