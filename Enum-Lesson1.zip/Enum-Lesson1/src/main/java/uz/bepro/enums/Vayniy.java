package uz.bepro.enums;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Enum-Lesson1}
 * @Date: {2022/05/10 && 9:17 PM}
 */
public enum Vayniy {
    //
    LETENANT,
    MAYOR,
    GENERAL;
}
