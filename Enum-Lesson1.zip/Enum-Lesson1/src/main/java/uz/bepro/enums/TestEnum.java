package uz.bepro.enums;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Enum-Lesson1}
 * @Date: {2022/05/10 && 8:58 PM}
 */
public enum TestEnum {

    ADMIN,
    USER,
    GUEST,
    STUDENT;
}
