package uz.bepro.project.electronics.devices;

import uz.bepro.project.electronics.Switchable;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 2:49 PM}
 */
public abstract class Devices implements Switchable {
    //
    double woltage;
    double amper;
}
