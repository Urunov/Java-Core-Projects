package uz.bepro.project.model;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/12 && 12:13 AM}
 */
public class Dog extends AnimalSimple {
    //

}
