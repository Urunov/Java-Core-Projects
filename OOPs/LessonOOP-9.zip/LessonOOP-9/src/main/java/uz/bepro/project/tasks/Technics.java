package uz.bepro.project.tasks;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 4:15 PM}
 */
public interface Technics {
    void turnOnOf();
    void repair();

}
