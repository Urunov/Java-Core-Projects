package uz.bepro.project.electronics.devices;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 4:01 PM}
 */
public interface Callable {

    void call();

}
