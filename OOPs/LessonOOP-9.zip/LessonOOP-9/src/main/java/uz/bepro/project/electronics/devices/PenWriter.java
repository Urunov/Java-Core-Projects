package uz.bepro.project.electronics.devices;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 4:04 PM}
 */
public class PenWriter extends Devices{

    @Override
    public void turnOn() {

    }

    @Override
    public void turnOff() {

    }
}
