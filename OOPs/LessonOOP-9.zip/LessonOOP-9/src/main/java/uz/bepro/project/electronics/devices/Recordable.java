package uz.bepro.project.electronics.devices;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 4:02 PM}
 */
public interface Recordable {
    void record();
}
