package uz.bepro.project.electronics;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 2:34 PM}
 */
public abstract class Electronics {

    public abstract void turnOn();
    public abstract void turnOff();
}
