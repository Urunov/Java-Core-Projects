package uz.bepro.project.model;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/12 && 12:10 AM}
 */
public class AnimalSimple {
    //
    public void voiceAnimal(){ // body
        System.out.println("sound ...");
    }
}
