package uz.abstr.func;

/**
 * @project: InhertanceImp
 * @Date: 02.08.2022
 * @author: H_Urunov
 **/
@FunctionalInterface
public interface CarDetails {

    public abstract void printDetails(String message);


}
